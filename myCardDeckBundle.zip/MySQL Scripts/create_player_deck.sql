CREATE TABLE `player_deck` (
  `player_owned_decks_id` bigint(20) DEFAULT NULL,
  `deck_id` bigint(20) DEFAULT NULL,
  KEY `FK212DBF47E02D6A8` (`player_owned_decks_id`),
  KEY `FK212DBF47812F2E99` (`deck_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1