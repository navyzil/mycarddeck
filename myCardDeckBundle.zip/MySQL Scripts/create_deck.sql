CREATE TABLE `deck` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `player_card1_id` bigint(20) DEFAULT NULL,
  `player_card2_id` bigint(20) DEFAULT NULL,
  `player_card3_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2EFCA94D335326` (`player_card1_id`),
  KEY `FK2EFCA94D343BE4` (`player_card3_id`),
  KEY `FK2EFCA94D33C785` (`player_card2_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1