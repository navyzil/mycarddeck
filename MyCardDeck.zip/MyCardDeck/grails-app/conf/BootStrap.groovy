import com.united.mycarddeck.domain.Card
import com.united.mycarddeck.domain.Deck
import com.united.mycarddeck.domain.Player
import com.united.mycarddeck.domain.Skills

class BootStrap {

    def init = { servletContext ->
		
		Skills skill1 = new Skills(name:"First Strike")
		if(!skill1.save(failOnError: true, flush:true)){
			log.error "Could not save!";
			log.error "${skill1.errors}"
		}
		Skills skill2 = new Skills(name:"Trample")
		if(!skill2.save(failOnError: true, flush:true)){
			log.error "Could not save!";
			log.error "${skill2.errors}"
		}
		
		Card playercard1 = new Card(name:"White Knight",strength:2, defense:2, cardSkills:[skill1,skill2])
		Card playercard2 = new Card(name:"Black Knight",strength:2, defense:2, cardSkills:[skill1])
		Card playercard3 = new Card(name:"Blood Knight",strength:2, defense:2, cardSkills:[skill1,skill2])
		
		if(!playercard1.save(failOnError: true, flush:true)){
			log.error "Could not save!";
			log.error "${playercard1.errors}"
		}
		if(!playercard2.save(failOnError: true, flush:true)){
			log.error "Could not save!";
			log.error "${playercard2.errors}"
		}
		if(!playercard3.save(failOnError: true, flush:true)){
			log.error "Could not save!";
			log.error "${playercard3.errors}"
		}

		Deck ownedDeck1 = new Deck(name:"Knight Deck", playerCard1:playercard1,playerCard2:playercard2, playerCard3:playercard3)
		
		if(!ownedDeck1.save(failOnError: true, flush:true)){
			log.error "Could not save!";
			log.error "${ownedDeck1.errors}"
		}
		
		Deck ownedDeck2 = new Deck(name:"Knight Deck2", playerCard1:playercard1,playerCard2:playercard2, playerCard3:playercard3)
		
		if(!ownedDeck2.save(failOnError: true, flush:true)){
			log.error "Could not save!";
			log.error "${ownedDeck2.errors}"
		}

		Deck ownedDeck3 = new Deck(name:"Knight Deck3", playerCard1:playercard1,playerCard2:playercard2, playerCard3:playercard3)
		
		if(!ownedDeck3.save(failOnError: true, flush:true)){
			log.error "Could not save!";
			log.error "${ownedDeck3.errors}"
		}

		int playerStrength = ownedDeck1.playerCard1.strength + ownedDeck1.playerCard2.strength + ownedDeck1.playerCard3.strength
		int playerDefense = ownedDeck1.playerCard1.defense + ownedDeck1.playerCard2.defense + ownedDeck1.playerCard3.defense
		
		
		Player player = new Player(strength:playerStrength,defense:playerDefense,ownedDecks:[ownedDeck1,ownedDeck2,ownedDeck3],ownedCards:[playercard1,playercard2,playercard3])
		println"player.ownedDecks:${player.ownedDecks}"
		println"player.ownedDecks:${player.ownedDecks.size()}"
		
		def ownedDeckList = player.ownedDecks.toList()
		player.currentDeck = ownedDeckList.get(0)
		println"player currentDeck:${player.currentDeck}"
		
		def card1Skill = player.currentDeck.playerCard1.cardSkills
		def card2Skill = player.currentDeck.playerCard2.cardSkills
		def card3Skill = player.currentDeck.playerCard3.cardSkills
		
		player.currentSkills=""
		card1Skill.each { if(it.name!=null){player.currentSkills+="${it.name},"} }
		card2Skill.each { if(it.name!=null){player.currentSkills+="${it.name},"} }
		card3Skill.each { if(it.name!=null){player.currentSkills+="${it.name},"} }
		
		
		if(!player.save(failOnError: true, flush:true)){
			log.error "Could not save!";
			log.error "${player.errors}"
		}
    }
    def destroy = {
    }
}
