package com.united.mycarddeck.domain

import com.sun.jndi.ldap.Obj;

class DeckController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index = {
        redirect(action: "list", params: params)
    }

    def list = {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [deckInstanceList: Deck.list(params), deckInstanceTotal: Deck.count()]
    }

    def create = {
        def deckInstance = new Deck()
        deckInstance.properties = params
        return [deckInstance: deckInstance]
    }

    def save = {
        def deckInstance = new Deck(params)
		deckInstance.playerCard1 = null
		deckInstance.playerCard2 = null
		deckInstance.playerCard3 = null
		deckInstance.properties = params
		
		if(deckInstance.playerCard1==null & deckInstance.playerCard2==null & deckInstance.playerCard3 == null){
			log.debug("fail")
			flash.message = deckInstance.errors.reject("deck.nocards")
			//"${message(code: 'default.updated.message', args: [message(code: 'deck.label', default: 'Deck'), deckInstance.id])}"
			render(view: "create", model: [deckInstance: deckInstance])
		}
		else if (deckInstance.save(flush: true)) {
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'deck.label', default: 'Deck'), deckInstance.id])}"
            redirect(action: "show", id: deckInstance.id)
        }
        else {
            render(view: "create", model: [deckInstance: deckInstance])
        }
    }

    def show = {
        def deckInstance = Deck.get(params.id)
        if (!deckInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'deck.label', default: 'Deck'), params.id])}"
            redirect(action: "list")
        }
        else {
            [deckInstance: deckInstance]
        }
    }

    def edit = {
        def deckInstance = Deck.get(params.id)
        if (!deckInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'deck.label', default: 'Deck'), params.id])}"
            redirect(action: "list")
        }
        else {
            return [deckInstance: deckInstance]
        }
    }

    def update = {
        def deckInstance = Deck.get(params.id)
        if (deckInstance) {
            if (params.version) {
                def version = params.version.toLong()
                if (deckInstance.version > version) {
                    
                    deckInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'deck.label', default: 'Deck')] as Object[], "Another user has updated this Deck while you were editing")
                    render(view: "edit", model: [deckInstance: deckInstance])
                    return
                }
            }
			deckInstance.playerCard1 = null
			deckInstance.playerCard2 = null
			deckInstance.playerCard3 = null
            deckInstance.properties = params
			
			if(deckInstance.playerCard1==null & deckInstance.playerCard2==null & deckInstance.playerCard3 == null){
				log.debug("fail")
				flash.message = deckInstance.errors.reject("deck.nocards")
				//"${message(code: 'default.updated.message', args: [message(code: 'deck.label', default: 'Deck'), deckInstance.id])}"
				render(view: "edit", model: [deckInstance: deckInstance])
			}
            else if (!deckInstance.hasErrors() && deckInstance.save(flush: true)) {
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'deck.label', default: 'Deck'), deckInstance.id])}"
                redirect(action: "show", id: deckInstance.id)
            }
            else {
                render(view: "edit", model: [deckInstance: deckInstance])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'deck.label', default: 'Deck'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def deckInstance = Deck.get(params.id)
        if (deckInstance) {
            try {
                deckInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'deck.label', default: 'Deck'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'deck.label', default: 'Deck'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'deck.label', default: 'Deck'), params.id])}"
            redirect(action: "list")
        }
    }
}
