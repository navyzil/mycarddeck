package com.united.mycarddeck.domain

class Card {
	
	String name
	int strength
	int defense
	
	static hasMany = [cardSkills:Skills]
	
    static constraints = {
		name(nullable:false,blank:false)
		strength(nullable:false,blank:false)
		defense(nullable:false,blank:false)
		
    }
}
