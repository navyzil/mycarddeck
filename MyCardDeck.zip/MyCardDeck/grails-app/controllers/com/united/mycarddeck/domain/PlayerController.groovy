package com.united.mycarddeck.domain

class PlayerController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index = {
        redirect(action: "show", params: params)
    }

    def list = {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [playerInstanceList: Player.list(params), playerInstanceTotal: Player.count()]
    }

    def create = {
        def playerInstance = new Player()
        playerInstance.properties = params
        return [playerInstance: playerInstance]
    }

    def save = {
        def playerInstance = new Player(params)
        if (playerInstance.save(flush: true)) {
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'player.label', default: 'Player'), playerInstance.id])}"
            redirect(action: "show", id: playerInstance.id)
        }
        else {
            render(view: "create", model: [playerInstance: playerInstance])
        }
    }

	def cardsIndex = {
		redirect(controller:"card", action:"index")		
	}
	
	def deckIndex = {
		redirect(controller:"deck", action:"index")
	}
	
	def skillsIndex ={
		redirect(controller:"skills", action:"index")
		
	}
    def show = {
		params.id='1'
        def playerInstance = Player.get(params.id)
		
		if (!playerInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'player.label', default: 'Player'), params.id])}"
            redirect(action: "list")
        }
        else {
			log.debug(playerInstance.currentDeck)
            [playerInstance: playerInstance]
        }
    }

	def playerCurrentDeck = {
		def playerInstance = Player.get(params.id)
        if (!playerInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'player.label', default: 'Player'), params.id])}"
            redirect(action: "list")
        }
        else {
            return [playerInstance: playerInstance] 
		}
    }
	
	def playerDeckManager = {
		def playerInstance = Player.get(params.id)
		
		if (!playerInstance) {
			flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'player.label', default: 'Player'), params.id])}"
			redirect(action: "list")
		}
		else {
			return [playerInstance: playerInstance]
		}
	}

	
	def playerCardManager = {
		def playerInstance = Player.get(params.id)
		if (!playerInstance) {
			flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'player.label', default: 'Player'), params.id])}"
			redirect(action: "list")
		}
		else {
			return [playerInstance: playerInstance]
		}
	}
	
    def edit = {
        def playerInstance = Player.get(params.id)
        if (!playerInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'player.label', default: 'Player'), params.id])}"
            redirect(action: "list")
        }
        else {
            return [playerInstance: playerInstance]
        }
    }

    def update = {
        def playerInstance = Player.get(params.id)
//		log.debug("playerInstance.currentDeck.strength:${playerInstance.currentDeck.playerCard1.strength}")
//		log.debug("playerInstance.currentDeck.defense:${playerInstance.currentDeck.playerCard1.defense}")
//		log.debug("playerInstance.currentDeck.cardSkills:${playerInstance.currentDeck.playerCard1.cardSkills}")
		
		
		playerInstance.strength = playerInstance.totalStrength(playerInstance?.currentDeck)
		playerInstance.defense = playerInstance.totalDefense(playerInstance?.currentDeck)
		playerInstance.currentSkills = playerInstance.listSkills(playerInstance?.currentDeck)
		
        if (playerInstance) {
            if (params.version) {
                def version = params.version.toLong()
                if (playerInstance.version > version) {
                    
                    playerInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'player.label', default: 'Player')] as Object[], "Another user has updated this Player while you were editing")
                    render(view: "edit", model: [playerInstance: playerInstance])
                    return
                }
            }
            playerInstance.properties = params
			log.debug(playerInstance.ownedDecks.size())
			
            if (!playerInstance.hasErrors() && playerInstance.save(flush: true)) {
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'player.label', default: 'Player'), playerInstance.id])}"
                redirect(action: "show", id: playerInstance.id)
            }
            else {
                render(view: "edit", model: [playerInstance: playerInstance])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'player.label', default: 'Player'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def playerInstance = Player.get(params.id)
        if (playerInstance) {
            try {
                playerInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'player.label', default: 'Player'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'player.label', default: 'Player'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'player.label', default: 'Player'), params.id])}"
            redirect(action: "list")
        }
    }
}
