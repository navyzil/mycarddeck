package com.united.mycarddeck.domain

class Skills {

	String name
    static constraints = {
		name(nullable:false,blank:false)
    }
}
