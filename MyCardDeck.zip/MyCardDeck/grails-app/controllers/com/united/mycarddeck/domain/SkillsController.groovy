package com.united.mycarddeck.domain

class SkillsController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index = {
        redirect(action: "list", params: params)
    }

    def list = {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [skillsInstanceList: Skills.list(params), skillsInstanceTotal: Skills.count()]
    }

    def create = {
        def skillsInstance = new Skills()
        skillsInstance.properties = params
        return [skillsInstance: skillsInstance]
    }

    def save = {
        def skillsInstance = new Skills(params)
        if (skillsInstance.save(flush: true)) {
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'skills.label', default: 'Skills'), skillsInstance.id])}"
            redirect(action: "show", id: skillsInstance.id)
        }
        else {
            render(view: "create", model: [skillsInstance: skillsInstance])
        }
    }

    def show = {
        def skillsInstance = Skills.get(params.id)
        if (!skillsInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'skills.label', default: 'Skills'), params.id])}"
            redirect(action: "list")
        }
        else {
            [skillsInstance: skillsInstance]
        }
    }

    def edit = {
        def skillsInstance = Skills.get(params.id)
        if (!skillsInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'skills.label', default: 'Skills'), params.id])}"
            redirect(action: "list")
        }
        else {
            return [skillsInstance: skillsInstance]
        }
    }

    def update = {
        def skillsInstance = Skills.get(params.id)
        if (skillsInstance) {
            if (params.version) {
                def version = params.version.toLong()
                if (skillsInstance.version > version) {
                    
                    skillsInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'skills.label', default: 'Skills')] as Object[], "Another user has updated this Skills while you were editing")
                    render(view: "edit", model: [skillsInstance: skillsInstance])
                    return
                }
            }
            skillsInstance.properties = params
            if (!skillsInstance.hasErrors() && skillsInstance.save(flush: true)) {
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'skills.label', default: 'Skills'), skillsInstance.id])}"
                redirect(action: "show", id: skillsInstance.id)
            }
            else {
                render(view: "edit", model: [skillsInstance: skillsInstance])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'skills.label', default: 'Skills'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def skillsInstance = Skills.get(params.id)
        if (skillsInstance) {
            try {
                skillsInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'skills.label', default: 'Skills'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'skills.label', default: 'Skills'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'skills.label', default: 'Skills'), params.id])}"
            redirect(action: "list")
        }
    }
}
