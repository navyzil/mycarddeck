
package com.united.mycarddeck.domain

class Deck {

	String name
	Card playerCard1
	Card playerCard2
	Card playerCard3
	
    static constraints = {
		playerCard1(nullable:true)
		playerCard2(nullable:true)
		playerCard3(nullable:true)
		name(nullable:false,blank:false)
		
		
    }

}
