package com.united.mycarddeck.domain

class Player {
	int strength
	int defense
	Deck currentDeck
	String currentSkills
	static hasMany = [ownedDecks:Deck,ownedCards:Card]
    static constraints = {
		
		ownedDecks(maxSize:10)
    }
	
	public int totalStrength(Deck currentDeck){
		strength = 0
		Card playerCard1 = currentDeck.playerCard1
		Card playerCard2 = currentDeck.playerCard2
		Card playerCard3 = currentDeck.playerCard3
		
		if(playerCard1!=null){
			strength+=playerCard1.strength
		}
		
		if(playerCard2!=null){
			strength+=playerCard2.strength
		}
		
		if(playerCard3!=null){
			strength+=playerCard3.strength
		}
		
		
		return strength
	}
	
	public int totalDefense(Deck currentDeck){
		Card playerCard1 = currentDeck.playerCard1
		Card playerCard2 = currentDeck.playerCard2
		Card playerCard3 = currentDeck.playerCard3
		defense = 0
		if(playerCard1!=null){
			defense+=playerCard1.defense
		}
		
		if(playerCard2!=null){
			defense+=playerCard2.defense
		}
		
		if(playerCard3!=null){
			defense+=playerCard3.defense
		}
		
		return defense
	}
	
	public String listSkills(Deck currentDeck){
		currentSkills = "";
		
		Card playerCard1 = currentDeck?.playerCard1
		Card playerCard2 = currentDeck?.playerCard2
		Card playerCard3 = currentDeck?.playerCard3
		
		if(playerCard1!=null){
			playerCard1.cardSkills.each {
				if(it.name!=null){
					currentSkills+="${it.name},"
				}
			}
		}
		
		if(playerCard2!=null){
			playerCard2.cardSkills.each {
				if(it.name!=null){
					currentSkills+="${it.name},"
				}
			}
		}
		
		if(playerCard3!=null){
			playerCard3.cardSkills.each {
				if(it.name!=null){
					currentSkills+="${it.name},"
				}
			}
		}
		return currentSkills
	}

}
