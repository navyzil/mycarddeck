CREATE TABLE `player` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version` bigint(20) NOT NULL,
  `current_deck_id` bigint(20) NOT NULL,
  `current_skills` varchar(255) NOT NULL,
  `defense` int(11) NOT NULL,
  `strength` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC53E9AE1903609D3` (`current_deck_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1