CREATE TABLE `card_skills` (
  `card_card_skills_id` bigint(20) DEFAULT NULL,
  `skills_id` bigint(20) DEFAULT NULL,
  KEY `FK2A767051F7512967` (`card_card_skills_id`),
  KEY `FK2A7670516B2D7839` (`skills_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1