CREATE TABLE `player_card` (
  `player_owned_cards_id` bigint(20) DEFAULT NULL,
  `card_id` bigint(20) DEFAULT NULL,
  KEY `FK212D3DAEEBBEC98F` (`player_owned_cards_id`),
  KEY `FK212D3DAE46454139` (`card_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1